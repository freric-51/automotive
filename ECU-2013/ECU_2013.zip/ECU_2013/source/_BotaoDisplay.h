/**
 *  \file _BotaoDisplay.h
 *  \brief protótipos de _BotaoDisplay.c
 */
