/**
 *  \file _estrategia.h
 *  \brief protótipos para _estrategia.c
 */

void Calcular_Estrategia(void);
void Calcular_Avanco_IGN(void);
void Calcular_Injecao(void); 
void Calcular_Aceleracao(void);
