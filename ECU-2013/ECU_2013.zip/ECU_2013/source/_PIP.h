/**
 *  \file _PIP.h
 *	\brief prototipos para _PIP.c
 */