/**
 * \file _ANA.h
 * \brief protótipos para _ANA.c
 */

//void AD_TRIS(void) ;
void AD_Next_Port_Choice (void);
