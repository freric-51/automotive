/**
 * \file _funcoes_gerais.h
 * \brief protótipos para _funcoes_gerais.c
 */

char *Int_to_ASCII(unsigned int);
void LongFix_to_ASCII(unsigned long int, int, char *);
int ASCII_TO_INT(char);